# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'
vec2difmat <- function(x){
  nx <- length(x)
  matrix(x, nrow=nx, ncol=nx) - matrix(x, nrow=nx, ncol=nx, byrow=T)
}

getinitfun <- function(Y, H, d, method='mave', submethod='csopg'){
  if(!is.element(method, c('mave', 'dr')))
    stop(paste0('Do not have this method: ', method, '\n'))
  if(method == 'mave'){
    if(is.element(submethod, c('csopg', 'csMAVE', 'meanOPG', 'meanMAVE', 'KSIR')))
    {
      require(MAVE)
      dr.csopg <- mave(Y ~ H, method = submethod)
      sdr <- dr.csopg$dir[[d]]
      return(sdr %*% qr.solve(sdr[1:d,1:d]))
    }else{
      stop(paste0('Do not have this submethod: ', submethod, ' in method:', method, '\n'))
    }
  }else if(method=='dr'){
    require(dr)
    if(is.element(submethod, c('sir', 'save', 'phdy', 'phdres'))){
      res <- dr(Y ~ H, method=submethod)
      hbeta1 <- res$evectors[,1:d]
    }else if(submethod == 'ire'){
      res <- dr(Y ~ H, method=submethod)
      res2 <- summary(res)
      hbeta1 <- res2$result[[d]]$B
    }else{
      stop(paste0('Do not have this submethod: ', submethod, ' in method:', method, '\n'))
    }
    hbeta1 <- matrix(hbeta1, q, d)
    return(hbeta1 %*% qr.solve(hbeta1[1:d,1:d])) # normalize
  }

}

factorm <- function(x, q=NULL){
  n <- nrow(x)
  p <- ncol(x)
  svdx <- eigen(x%*%t(x))
  evalues <- svdx$values
  propcum <- cumsum(evalues)/sum(evalues)
  if(is.null(q)){
    q <- which(propcum > 0.9)[1]
  }
  hatF <- svdx$vector[, 1:q] * sqrt(n)
  hatB  <- n^(-1)*t(x) %*% hatF
  sB <- sign(hatB[1, ])
  hB <- hatB * matrix(sB, nrow=p, ncol=q, byrow=T)
  hatF<- t(apply(hatF, 1, '*', sB ))
  cF <- cov(hatF )
  svdcF <- svd(cF)
  sovleF <- svdcF$u %*% diag((svdcF$d)^(-1/2))%*% t(svdcF$v)
  hatF <- (hatF- matrix(apply(hatF, 2, mean), n, q, byrow = T)) %*% sovleF
  res <- list()
  res$H <- hatF
  res$B <- hB
  res$q <- q
  res$propvar <- propcum[q]
  attr(res, 'class') <- 'fac'
  return(res)

}
# maximization objective function
objfun <- function(vecbeta,Y,X, B, H, omega, Full=0){
  d <- 2
  q <- ncol(H)
  beta <- matrix(vecbeta, nrow=q, ncol=d)
  omega <- p^(-1/2)
  eps1 <- 1e-16
  bH <- H %*% beta
  YH <- cbind(Y, bH)
  fYH <- kde(YH, eval.points = YH)$estimate
  fH <- kde(bH, eval.points = bH)$estimate
  C1 <- mean(log(fYH/fH + eps1))
  if( Full == 0) return(C1)
  C = C1 - 1/n*omega * norm(X - H%*%t(B), 'F')^2
  return(C)
}

kern <- function(u, type='normal'){
  if(!is.element(type, c('epk', 'biweight', 'triangle',
                         'normal', 'triweight', 'tricube', 'cosine', 'uniform')))
    stop("type must belong to 'epk', 'biweight', 'triangle',
         'normal', 'triweight', 'tricube', 'cosine', 'uniform'!")
  if (type=="epk") f = 0.75*(1-u^2)*(u<=1& u>=-1)
  else if (type=='biweight') f = (15/16)*(1 - u^2)^2*(u<=1& u>=-1 )
  else if (type=='triangle') f = (1-abs(u))*(u<=1& u>=-1)
  else if (type=='normal') f = dnorm(u)
  else if (type=='triweight') f = 35/32*(1-u^2)^3*(u<=1& u>=-1)
  else if (type=='tricube') f = 70/81*(1-abs(u)^3)^3*(u<=1& u>=-1)
  else if (type=='cosine') f = pi/4*cos(pi*u/2)
  else if (type=='uniform') f = 1/2*(u<=1& u>=-1 )
  return(f)
}

kern.deriv <- function(x, kerntype='normal'){
  if(kerntype =='normal')
    f = -x * exp(-0.5 * x^2) / sqrt(2*pi)
  return(f)
}

objFun <- function(Y, X, bet, h, b){
  YdY <- vec2difmat(Y)
  KyMat <- kern(YdY/h)/h
  Zb <- X %*% bet
  ZdZ <- vec2difmat(Zb)
  KzMat <- kern(ZdZ/b)/b
  -mean(log(mean(KyMat*KzMat)) - log(mean(KzMat)))
}

sdr_like_eval1 <- function(Y, H, betainit=NULL,initmethod=c('mave', 'csMAVE'), h=NULL, b=NULL, control.list=list(maxiter = 50,
                                                                                                                 eps_beta = 1e-6,
                                                                                                                 eps_obj = 1e-5,
                                                                                                                 eps1 = 1e-15
)){
  n <- length(Y)
  YdY <- vec2difmat(Y)
  q <- ncol(H)
  XdX <- array(0, c(n,n,q))
  for(j in  1:q){
    XdX[,,j] <- vec2difmat(H[,j])
  }

  maxiter <- control.list$maxiter
  eps_beta <- control.list$eps_beta
  eps_obj <- control.list$eps_obj
  eps1 <- control.list$eps1
  if(is.null(betainit)){
    veclbeta0 <- getinitfun(Y,H,1, method=initmethod[1], submethod = initmethod[2])
  }else{
    veclbeta0 <- betainit
  }
  h <- ifelse(is.null(h), n^(-1/3), h)
  b <- ifelse(is.null(b), n^(-1/5), b)
  history <- list()
  for(k in 1:maxiter){ # MM algorithm
    beta_tmp <- veclbeta0
    Zb <- H %*% beta_tmp
    ZbdZb <- vec2difmat(Zb)
    # ZbdZb[1:5,1:5]
    KyMat <- kern(YdY/h)/h
    KzbMat <- kern(ZbdZb/b)/b
    KyzMat <- KyMat * KzbMat
    Alpha <- KyzMat / (matrix(apply(KyzMat,1, sum),n,n)+eps1)
    bb <- 1/(n*h^2)* array(Alpha, c(n,n, q)) * XdX
    A <- matrix(0, q, q)
    for(i in 1:n){
      A <- A + t(bb[i,,])%*% XdX[i,,]
    }
    gami <- 1 / (apply(KzbMat, 1, sum)+eps1)
    gamMat <- matrix(gami, n, n, byrow=T)
    Kderiv <- -kern.deriv(ZbdZb/b)/b/b
    ctmp <- gamMat * Kderiv
    atmp <- apply(array(ctmp, c(n,n, q)) * XdX, c(2,3), sum)
    C <- apply(atmp, 2, mean)
    bet <- qr.solve(A) %*% C
    veclbeta0 <- bet / bet[1]
    veclbeta_dif <- sum((veclbeta0 - beta_tmp)^2)
    objvalue <- objFun(Y, H, veclbeta0, h, b)
    obj_dif <- objFun(Y, H, beta_tmp, h, b) - objvalue
    cat('k = ',k, 'beta_err=', veclbeta_dif, 'obj_err=',
        obj_dif, 'objvalue=', objvalue, '\n')
    history$iter=k; history$beta_err[k]<- veclbeta_dif;
    history$objvalue[k] <- objvalue;history$obj_err[k]<- obj_dif;
    history$betamat <- cbind(history$betamat, veclbeta0)
    if(veclbeta_dif < eps_beta || abs(obj_dif)<eps_obj)
      break
  }
  history$hbeta <- veclbeta0
  history$bandwidth <- c(h, b)
  return(history)
}

likeFADR <- function(Y, X, q=NULL,...){
  if(is.null(q)) q <- selectqdfun(Y, X)['q']
  res <- list()
  fac <- factorm(X, q)
  hH <- fac$H
  res$H <- hH
  res$B <- fac$B
  hist <- sdr_like_eval1(Y, hH, ...)
  res$hbeta <- hist$hbeta
  res$history <- hist
  res$data <- list(Y=Y, X= X)
  class(res) <- 'likeFADR'
  return(res)
}

cor.mat <-function(p, rho, type='toeplitz'){

  mat <- diag(p)
  if(type=='toeplitz'){
    for(i in 2:p){
      for(j in 1:i){
        mat[i,j] <- mat[j,i] <- rho^(abs(i-j))
      }
    }
  }
  if(type=='identity'){
    mat[mat==0] <- rho
  }
  return(mat)
}


#----------------Fan, J., Xue, L., and Yao, J. (2017). Sufficient forecasting
# using factor models. Journal of Econometrics.
evalFADR <- function(Y, X, q, d,method='sir', ...){
  # test input arguments
  if(inherits(Y,'numeric')) Y <- matrix(Y, nrow=length(Y))
  if(!inherits(Y, 'matrix')) stop('Y must be a vector or 1-column matrix!')
  if(!inherits(X, 'matrix')) stop('X must be a matrix!')
  if(nrow(Y) != nrow(X)) stop('the length of Y must be equal to the row of X!')
  if(q < 0 || d < 0 || d > q) stop('q or d must be a postive number and q >= d! ')
  res <- list()
  require(dr)
  fac <- factorm(X, q)
  hH <- fac$H
  res$H <- hH
  res$B <- fac$B
  res1 <- dr(Y ~ hH, method=method, ...)
  if(is.element(method, c('sir', 'save', 'phdy', 'phdres'))){
    hbeta1 <- res1$evectors[,1:d]
  }else if(method == 'ire'){
    res2 <- summary(res1)
    hbeta1 <- res2$result[[d]]$B
  }else{
    stop(paste0('Do not have this method: ', method, '\n'))
  }
  hbeta1 <- matrix(hbeta1, q, d)
  hbeta <- hbeta1 %*% qr.solve(hbeta1[1:d,1:d]) # normalize
  res$hbeta <- hbeta
  class(res) <- 'FADR'
  return(res)
}


#----------the function to select q and d
selectqdfun <- function(Y, X, method='mave'){
  evalues <- eigen(X%*%t(X))$values
  q <- which(cumsum(evalues)/sum(evalues) > 0.9)[1]
  fac <- factorm(X, q)
  hH <- fac$H
  require(MAVE)
  res1 <- mave(Y ~ hH, method='csmave')
  d <- which.min(mave.dim(res1)$cv)
  return(c(q = q, d= d))
}

# Simulation data generation functions ------------------------------------
dataSimulator <- function(use = 'factorm',n=300, p=500, seed=1){
  set.seed(seed)
  q <- 6
  ar_mat <- p * cor.mat(p, 0.5)
  Z <- mvrnorm(n, rep(0,p), ar_mat)
  svdx <- eigen(Z%*%t(Z))
  B <- t(Z) %*% svdx$vector[, 1:q] * sqrt(1/n)
  sB <- sign(B[1, ])
  B <- B * matrix(sB, p, q, byrow=T)
  H <- mvrnorm(n, rep(0,q), cor.mat(q, 0.5))
  cH <- cov(H)
  mH <- apply(H, 2, mean)
  svdcF <- svd(cH)
  solveF <- svdcF$u %*% diag((svdcF$d)^(-1/2))%*% t(svdcF$v)
  H <- (H - matrix(mH, n, q, byrow=T)) %*% solveF
  X <- H %*% t(B) + mvrnorm(n, rep(0,p), 1/sqrt(12*p)*diag(rep(1,p)))
  if(use == 'factorm'){
    return(list(X=X, H=H, B = B))
  }else if(use == 'likeFADR'){
    beta1 <- c(1,0,1,1,1,1)
    beta <- cbind(beta1)
    d <- 1
    q <- length(beta)
    Y <- H%*%beta/(0.5 + (H%*%beta + 1.5)^2) + (H%*%beta)^2*rnorm(n,0, sd= 1)
    return(list(X=X, Y=Y, beta=beta, H=H, B=B))
  }else if(use == 'FADR'){
    beta1 <- c(1,0,1,1,1,1)
    beta2 <- c(0,1,-1,1,-1,1)
    beta <- cbind(beta1, beta2)
    d <- 2
    q <- nrow(beta)
    ar_mat <- p * simutool::cor.mat(p, 0.5)
    Z <- mvrnorm(n, rep(0,p), ar_mat)
    svdx <- eigen(Z%*%t(Z))
    B <- t(Z) %*% svdx$vector[, 1:q] * sqrt(1/n)
    sB <- sign(B[1, ])
    B <- B * matrix(sB, p, q, byrow=T)
    H <- mvrnorm(n, rep(0,q), cor.mat(q, 0.5))
    cH <- cov(H)
    mH <- apply(H, 2, mean)
    svdcF <- svd(cH)
    solveF <- svdcF$u %*% diag((svdcF$d)^(-1/2))%*% t(svdcF$v)
    H <- (H - matrix(mH, n, q, byrow=T)) %*% solveF
    X <- H %*% t(B) + mvrnorm(n, rep(0,p), 1/sqrt(12*p)*diag(rep(1,p)))
    Y <- H%*%cbind(beta1)/(0.5 + (H%*%beta2 + 1.5)^2) + (H%*%beta1)^2*rnorm(n,0, sd= 1)
    list(X=X, Y=Y, beta=beta, H=H, B=B)
  }
}

#---evaluate FADR
evalFADR <- function(Y, X, q, d,method='sir', ...){
  require(dr)
  # test input arguments
  if(inherits(Y,'numeric')) Y <- matrix(Y, nrow=length(Y))
  if(!inherits(Y, 'matrix')) stop('Y must be a vector or 1-column matrix!')
  if(!inherits(X, 'matrix')) stop('X must be a matrix!')
  if(nrow(Y) != nrow(X)) stop('the length of Y must be equal to the row of X!')
  if(q < 0 || d < 0 || d > q) stop('q or d must be a postive number and q >= d! ')
  res <- list()
  require(dr)
  fac <- factorm(X, q)
  hH <- fac$H
  res$H <- hH
  res$B <- fac$B
  res1 <- dr(Y ~ hH, method=method, ...)
  if(is.element(method, c('sir', 'save', 'phdy', 'phdres'))){
    hbeta1 <- res1$evectors[,1:d]
  }else if(method == 'ire'){
    res2 <- summary(res1)
    hbeta1 <- res2$result[[d]]$B
  }else{
    stop(paste0('Do not have this method: ', method, '\n'))
  }
  hbeta1 <- matrix(hbeta1, q, d)
  hbeta <- hbeta1 %*% qr.solve(hbeta1[1:d,1:d]) # normalize
  res$hbeta <- hbeta
  class(res) <- 'FADR'
  return(res)
}
# Fan, 2017, sufficient forecasting model --------------------------------
FADR <- function(Y, X,q=NULL, d=NULL, ...){
  if(is.null(q) || is.null(d)){
    qd <- selectqdfun(Y, X)
    q <- qd[1]
    d <- qd[2]
  }
  res <- evalFADR(Y, X, q, d, ...)
  res$data <- list(Y=Y, X= X)
  return(res)
}

# #--------------regression and prediction --------------------------------

#---- assist function
long2shortype <- function(longtype){
  shorttype <- c('n', 'e', 'b', 't', 'q')
  alltype <- c('normal', 'epk', 'box', 'triangle', 'quatic')
  flag.type <- pmatch(longtype, alltype , nomatch = 0)
  return(shorttype[flag.type[1]])
}
#----kernel function
kernR <- function(x, type='normal'){

  if(! (is.numeric(x))) stop('x must be nuemric!')
  if(! is.character(type)) stop('type must be character!')
  stype <- long2shortype(type)
  y <- kernelvec(x, stype)
  if(is.null(dim(x))) return(y)
  return(array(y, dim(x)))
}

#--- kernel derivative function
kern_derivR <- function(x, type='n'){
  if(! (is.numeric(x))) stop('x must be nuemric!')
  if(! is.character(type)) stop('type must be character!')
  stype <- long2shortype(type)
  dy <- kern_deriv(x, stype)
  if(is.null(dim(x))) return(dy)
  return(array(dy, dim(x)))
}

#--- local polynomial regression
locpolyR <- function(y, x, x0=x, degree=1, deriv=1, width=NULL, type='normal'){
  if(! is.character(type)) stop('type must be character!')
  stype <- long2shortype(type)
  y <- as.vector(y); x <- as.vector(x); x0 <- as.vector(x0)
  if(! (is.numeric(y) && is.numeric(x) && is.numeric(x0))) stop('y, x and x0 must be nuemric!')
  if(! (is.vector(y) && is.vector(x))) stop('y and x must be vecotr')
  if((n<- length(y)) != length(x)) stop('The length does not match for y and x!')
  if(is.null(width)) width <- n^(-1)*sd(x)

  reglist <- locpoly(y, x, x0, degree, deriv, width, stype)
  reg <- reglist$regmat
  res <- list()
  res$x0 <- x0
  res$fit0 <- reg[1,]
  cend <- nrow(reg)
  if(cend > 2) dymat <- t(reg[2:cend, ])
  if(cend == 2) dymat <- as.matrix(reg[2,])
  colnames(dymat) <- paste0('d', 1:(cend-1),'y')
  if(deriv==0){
    res$deriv <- NULL
  } else{
    res$deriv <- dymat[,deriv]
  }

  res$derivmat <- dymat
  res$width <- reglist$width
  class(res) <- 'locpolyR'
  return(res)
}


#----------- local linear for x \in R^2
locallinear2R <- function(y, x, x0=x, width = NULL, type='normal'){
  if(! is.character(type)) stop('type must be character!')
  stype <- long2shortype(type)
  if((n<- length(y)) != nrow(x)) stop('The shape does not match for y and x!')
  if(ncol(x) != ncol(x0)) stop('Number of column does not match for x and x0!')
  if(is.null(width)) width <- n^(-1)*apply(x, 2, sd)

  reglist2 <- locallinear2(y, x, x0, width,stype)
  reg <- reglist2$regmat
  res <- list()
  res$x0 <- x0
  res$fit0 <- reg[1,]
  dymat <- t(reg[2:3,])
  colnames(dymat) <- paste0('dy', 1:2)
  res$dy <- dymat
  res$width <- reglist2$width
  return(res)
}


predict.FADR <- function(obj, newdata, method='localreg', ...){
  if(!inherits(objFADR, 'FADR')) stop('obj must be FADR class!')
  require(randomForest)
  hbeta <- obj$hbeta
  Y <- obj$data$Y
  hB <- obj$B
  hH <- obj$H
  newH <- newdata %*% hB%*% qr.solve(t(hB)%*%hB)
  newW <- newH %*% hbeta
  oldW <- hH %*% hbeta
  if(method == 'localreg'){
    if((d <- ncol(hbeta))>2) stop('Can not handle the case by localreg where d>2!, and you
                                  can use randomForest method')
    if(d == 1){
      resreg <- locpolyR(Y, oldW, newW, ...)
    }else if(d == 2){

      resreg <- locallinear2R(y=as.vector(Y), x=oldW, x0=newW, ...)
    }
    hnewY <- resreg$fit0
  }else if(method=='randomForest'){
    rf <- randomForest(x=oldW, y=Y, ...)
    hnewY <- predict(rf, newdata=newW, type='response')
  }

  res <- list()
  res$newW <- newW
  res$predict <- hnewY
  res$method <- method
  return(res)
  }

predict.likeFADR <- function(obj, newdata, method='localreg', ...){
  if(!inherits(obj, 'likeFADR')) stop('obj must be likeFADR class!')
  require(randomForest)
  hbeta <- obj$hbeta
  Y <- obj$data$Y
  hB <- obj$B
  hH <- obj$H
  newH <- newdata %*% hB%*% qr.solve(t(hB)%*%hB)
  newW <- newH %*% hbeta
  oldW <- hH %*% hbeta
  if(method == 'localreg'){
    if((d <- ncol(hbeta))>2) stop('Can not handle the case by localreg where d>2!, and you
                                  can use randomForest method')
    if(d == 1){
      resreg <- locpolyR(Y, oldW, newW, ...)
    }else if(d == 2){

      resreg <- locallinear2R(y=as.vector(Y), x=oldW, x0=newW, ...)
    }
    hnewY <- resreg$fit0
  }else if(method=='randomForest'){
    rf <- randomForest(x=oldW, y=Y, ...)
    hnewY <- predict(rf, newdata=newW, type='response')
  }

  res <- list()
  res$newW <- newW
  res$predict <- hnewY
  res$method <- method
  return(res)
  }
