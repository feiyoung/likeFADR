#include<RcppArmadillo.h>
//[[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;
using namespace sugar;// it is more convenient.
using namespace arma;
NumericVector normal(NumericVector z){
  return exp(-0.5 * pow(z, 2)) / sqrt(2*M_PI);
}
NumericVector epanechinikov(NumericVector z){
  NumericVector w, f;
  w = abs(z) <= 1;
  f = .75 * w* (1 -pow(z, 2));
  return f;
}
NumericVector box(NumericVector z){
  //BOX    Box-shaped kernel
  double a;
  NumericVector f;
  a = sqrt(3);
  f = abs(z) <= a;
  return f / (2 * a);
}
NumericVector triangle(NumericVector z){
  //TRIANGLE Triangular kernel.
  double a;
  NumericVector w, f;
  a = sqrt(6);
  w = abs(z);
  f = w <= a;
  return f * (1 - w/a) / a;
}
NumericVector quatic(NumericVector z){
  // quatic high order-kernel to accelerate convergence.
  NumericVector w, f;
  w = abs(z);
  f = w <= 1;
  return f * (1 - pow(z, 2)) *0.75;
}
// kernel derivative 
NumericVector normald(NumericVector z){
  //NORMAL Normal density kernel derivative.
  return -z* exp(-0.5 * pow(z, 2)) / sqrt(2*M_PI);;
}
  

NumericVector epanechinikovd(NumericVector z){
  //EPANECHINIKOV Epanechinikov's asymptotically optimal kernel.//'
  NumericVector w, f;
  w = abs(z);
  f = w <= 1;
  return - 3/2 *z * f;
}

NumericVector triangled(NumericVector z){
  //TRIANGLE Triangular kernel.
  NumericVector w, f;
  w = abs(z);
  f = w <= 1;
  return -105/16 * z * pow(1-pow(z,2),2)*f;
}
  

NumericVector biweightd(NumericVector z){
  // BIWEIGHT Biweight kernel.
  NumericVector f;
  f = abs(z) <= 1;
  return - 15/4 * z *(1-pow(z, 2)) *f;
}

NumericVector tricubed(NumericVector z){
  // TRICUBE Tricube kernel.
  NumericVector f, w;
  f = abs(z) <= 1;
  w = sign(z); // can not compute in one step.
  return -70/9 * pow(1-pow(z, 3), 2)* pow(z,2) * w *f;
}

//[[Rcpp::export]]
NumericVector kernelvec(NumericVector x, String type){
  NumericVector w;
  if(type == "n"){
    w = normal(x);
  }else if(type == "e"){
    w = epanechinikov(x);
  }else if(type == "b"){
    w = box(x);
  }else if(type =="t"){
    w = triangle(x);
  }else if(type == "q"){
    w = quatic(x);
  }
  return w;
}

//[[Rcpp::export]]
NumericVector kern_deriv(NumericVector x, String type){
  NumericVector w;
  if(type == "n"){
    w = normald(x);
  }else if(type == "e"){
    w = epanechinikovd(x);
  }else if(type == "b"){
    w = biweightd(x);
  }else if(type =="g"){
    w = triangled(x);
  }else if(type == "c"){
    w = tricubed(x);
  }
  return w;
}

//  pointwise estimates for E(Y|X=x0) and its derivatives, including higher
// order derivatives
//[[Rcpp::export]]
arma::vec pointwise_reg(arma::vec y, NumericVector x, double x0, String kerntype, double width, int degree){
  int n = y.size();
  int t;
  NumericMatrix X(n, degree+1);
  NumericVector w;
  arma::vec halpha;
  List res;
  NumericVector nv = x - rep(x0, n); // need x0 have same length.
  X(_,0) = rep(1,n);
  for(int j = 0; j<degree; j++){
    t = j + 1;
    X(_,t) = pow(nv,t);
  }
  w = kernelvec(nv/width, kerntype) / width;
  arma::vec v = Rcpp::as<arma::vec>(w); //NumericVector  can be transfer into vec well.
  arma::mat W = diagmat(v);
  arma::mat Z = as<mat>(X); // NumericMatrix => mat well.
  halpha = (Z.t()*W*Z).i()*(Z.t()*W*y);
  return halpha;
}

// local polynomial regression
//[[Rcpp::export]]
List locpoly(arma::vec y, NumericVector x, NumericVector x0, int degree, int deriv, double width, String type){
  int n = y.size(), n0 = x0.size();
  arma::mat Alpha(degree+1, n0);
  arma::vec tmp;
  List res;
  double med, sig;
  NumericVector tmp2;
  double tmp3 = 4/(3*n);
  if(degree < deriv){
    stop("degree must be greater than derivative!"); // provide information
  }
  if(width == 0){
    med = median(x);
    tmp2 = abs(x - med);
    sig = median(tmp2) / 0.6745;
    if (sig>0){
      width = sig * pow(tmp3, 1/6)/ 2;
    }
    else{
      width= 1;
    }
  }
  // start local regression
  //tmp = pointwise_reg(y, x, x0[0], type, width, degree);
  for(int i=0; i< n0; i++){
    Alpha.col(i) = pointwise_reg(y, x, x0[i], type, width, degree); // vec is column vector as default.
  }
  res["regmat"] = Alpha;
  res["width"] = width;
  res.attr("class") = "locpoly";
  return res;
}

// when Y in R, and X in R^2, local linear
arma::vec pointwise_reg2(vec y, NumericMatrix x, NumericVector x0, String kerntype, NumericVector width){
  int n = y.size();
  double eps1 = 1e-12;
  NumericVector w1, w2, w;
  arma::vec halpha;
  arma::mat xtmp = as<mat>(x);
  arma::vec xotmp  = as<vec>(x0);
  arma::mat X = zeros(n, 3);
  X.col(0) = ones(n,1);
  X(span::all, span(1,2) ) = xtmp - repmat(xotmp.t(), n, 1);
  NumericVector nv1 = x(_, 0) - rep(x0[0], n);
  NumericVector nv2 = x(_, 1) - rep(x0[1], n);
  w1 = kernelvec(nv1/width[0], kerntype) / width[0];
  w2 = kernelvec(nv2/width[1], kerntype) / width[1];
  w = w1 * w2;
  arma::vec v = as<vec>(w);
  arma::mat W = diagmat(v);
  halpha = (X.t()*W*X + eps1*eye<mat>(3,3)).i()*(X.t()*W*y);
  return halpha;
}

//[[Rcpp::export]]
arma::mat locallinear2_eval(arma::vec y, NumericMatrix x, NumericMatrix x0,NumericVector width, String type){
  int n0 = x0.nrow();
  arma::mat Alpha(3, n0);

  // start local regression
  
  for(int i=0; i< n0; i++){
    Alpha.col(i) = pointwise_reg2(y, x, x0.row(i), type, width); // vec is column vector as default.
  }
  return Alpha;
}

//[[Rcpp::export]]

List locallinear2(arma::vec y, NumericMatrix x, NumericMatrix x0,NumericVector width, String type){
  List res;
  arma::mat Alpha;
  // start local regression
  
  Alpha = locallinear2_eval(y, x, x0, width, type);
  
  res["regmat"] = Alpha;
  res["width"] = width;
  res.attr("class") = "locallinear2";
  return res;
}

// Y \in R^p, X \in R^2
//[[Rcpp::export]]
List locallinear2p(NumericMatrix y, NumericMatrix x, NumericMatrix x0,NumericVector width, String type){
  int n0 = x0.nrow(), p = y.ncol();
  arma::rowvec vec1;
  arma::mat Alpha(p, n0);
  arma::mat tmpmat;
  List res;
  // start local regression
  for(int j=0; j< p; j++){
    tmpmat = locallinear2_eval(y(_,j), x, x0, width, type);
    vec1 = tmpmat.row(0);
    Alpha.row(j) = vec1; // vec is column vector as default.
  }
  res["regmat"] = Alpha;
  res["width"] = width;
  res.attr("class") = "locallinear2p";
  return res;
}
